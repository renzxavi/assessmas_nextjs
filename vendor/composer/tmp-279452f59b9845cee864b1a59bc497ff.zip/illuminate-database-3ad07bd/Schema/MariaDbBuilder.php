<?php

namespace Illuminate\Database\Schema;

class MariaDbBuilder extends MySqlBuilder
{
    //
}
