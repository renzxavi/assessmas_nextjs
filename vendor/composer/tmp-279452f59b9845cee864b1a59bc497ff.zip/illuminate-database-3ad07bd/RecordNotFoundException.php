<?php

namespace Illuminate\Database;

use RuntimeException;

class RecordNotFoundException extends RuntimeException
{
    //
}
